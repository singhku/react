import React from 'react'
const Person = (props)=>{
return(
    <div>
<p>New component,Well done  {props.name} and Age {props.age}</p>
<p>{props.children}</p>
    </div>

)
};
 export default Person;