import React ,{useState}from 'react';
import logo from './logo.svg';
import './App.css';
import Person from './person/person';
import { render } from '@testing-library/react';

const  App =props=> {
  const [personState,setPersonState]=useState({
    
      person:[
        {name:'Kuber',age:30},
        {name:'sonu',age:35},
        {name:'Rocker',age:35}
      ],
      otherValue:'new value'
  });

 const namechageHandler=()=>{
    setPersonState({
      person:[
        {name:'KuberChanged',age:23},
        {name:'sonu',age:35},
        {name:'Rocker',age:35}
      ]
    });
  };

    return (
      <div className="App">
     <h1>Hi Kuber Lage raho </h1>
     <button onClick={namechageHandler}>Click me</button>
        <Person name={personState.person[0].name} age={personState.person[0].age}/>
        <Person name={personState.person[1].name} age={personState.person[1].age}/>
        <Person name={personState.person[2].name} age={personState.person[2].age}> Lets test</Person>
  
      </div>
    );
  };
  


export default App;



// {
  // state={
  //   person:[
  //     {name:'Kuber',age:30},
  //     {name:'sonu',age:35},
  //     {name:'Rocker',age:35}
  //   ],
  //   otherValue:'new value'
//   }

  // namechageHandler=()=>{
  //   this.setState({
  //     person:[
  //       {name:'KuberChanged',age:23},
  //       {name:'sonuChanged',age:78},
  //       {name:'RockerChanged',age:44}
  //     ]
  //   })
//     console.log(this.person);
//   }
//   render(){
//     return (
//       <div className="App">
//      <h1>Hi Kuber Lage raho </h1>
//      <button onClick={this.namechageHandler}>Click me</button>
//         <Person name={this.state.person[0].name} age={this.state.person[0].age}/>
//         <Person name={this.state.person[1].name} age={this.state.person[1].age}/>
//         <Person name={this.state.person[2].name} age={this.state.person[2].age}> Lets test</Person>
  
//       </div>
//     );
//   }
  
// }
